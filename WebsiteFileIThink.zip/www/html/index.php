<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	
 <meta http-equiv="refresh" content="5;   url=Main.php" />
		
	<title>Full Page Background Image | Progressive</title>
	
	<style>
		* { margin: 0; padding: 0; }
		
		html { 
			background: url(images/bg.jpg) no-repeat center center fixed; 
			-webkit-background-size: cover;
			-moz-background-size: cover;
			-o-background-size: cover;
			background-size: cover;
		}
		
		#page-wrap { 
			width: 400px; 
			margin: 50px auto; 
			padding: 20px; 
			background: white; 
			-moz-box-shadow: 0 0 20px black; 
			-webkit-box-shadow: 0 0 20px black; 
			box-shadow: 0 0 20px black; 
			
			
			}
		p { font: 15px/2 Georgia, Serif; margin: 0 0 30px 0; text-indent: 40px; }
	</style>
</head>

<body>

    <div id="logocontainer">
	
	<IMG alt="logo fuma" src="images/logo_fuma.png" /><br/>
	<IMG class="centerpic" alt="logo fuma" width="450px" height="50px" src="images/load.gif" /><br/>
	
	
    </div>
	
 <style type="text/css" style="display: none !important;">
	* {
		margin: 0;
		padding: 0;
	}
	body {
		overflow-x: hidden;
	}
	
	.centerpic{
		display: block;
    margin-left: auto;
    margin-right: auto
	}
	
	#logocontainer{
		z-index: 1;
		width:700px;
		height:500px;
		background:;
		margin: 100px auto; 
		padding: 20px; 
	}
	
	
	#demo-top-bar {
		text-align: left;
		background: #222;
		position: relative;
		zoom: 1;
		width: 100% !important;
		z-index: 6000;
		padding: 20px 0 20px;
	}
	#demo-bar-inside {
		width: 960px;
		margin: 0 auto;
		position: relative;
		overflow: hidden;
	}
	#demo-bar-buttons {
		padding-top: 10px;
		float: right;
	}
	#demo-bar-buttons a {
		font-size: 12px;
		margin-left: 20px;
		color: white;
		margin: 2px 0;
		text-decoration: none;
		font: 14px "Lucida Grande", Sans-Serif !important;
	}
	#demo-bar-buttons a:hover,
	#demo-bar-buttons a:focus {
		text-decoration: underline;
	}
	#demo-bar-badge {
		display: inline-block;
		width: 302px;
		padding: 0 !important;
		margin: 0 !important;
		background-color: transparent !important;
	}
	#demo-bar-badge a {
		display: block;
		width: 100%;
		height: 38px;
		border-radius: 0;
		bottom: auto;
		margin: 0;
		background: url(/images/examples-logo.png) no-repeat;
		background-size: 100%;
		overflow: hidden;
		text-indent: -9999px;
	}
	#demo-bar-badge:before, #demo-bar-badge:after {
		display: none !important;
	}
</style>
</body>

</html>