<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="css/main_site.css" />
<script type="text/javascript"
  src="dygraph-combined-dev.js"></script>
<title>Welcome to CTU Radio Antenna Projects</title>
</head>
	<script>
function openWin() {
	window.open("http://www.w3schools.com");
}
</script>
<!-- Custom Login/Register/Password Code-->
<!-- jQuery -->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
<script type="text/javascript" charset="utf-8">
		jQuery(document).ready(function() {
			jQuery(".tab_content_login").hide();
			jQuery("ul.tabs_login li:first").addClass("active_login").show();
			jQuery(".tab_content_login:first").show();
			jQuery("ul.tabs_login li").click(function() {
		jQuery("ul.tabs_login li").removeClass("active_login");
		jQuery(this).addClass("active_login");
		jQuery(".tab_content_login").hide();
			var activeTab = jQuery(this).find("a").attr("href");
			if (jQuery.browser.msie) {jQuery(activeTab).show();}
			else {jQuery(activeTab).show();}
			return false;
			});
		});
</script>

<!-- Custom Login/Register/ -->
<body>
    
   <div class="all_border_radio_25" id="page_container">

<div id="maincontainer">
		<div id="TopContainer">

			<div id="logo">
				<img class="leftpic" src="images/cpt.png"/>
				
			</div>
			<div id="logoTitle">
				<p class="logo text_center type_raleway font_size_18 font_white uppercase">Capitol Technology University</p>
				<p class="logo text_center type_raleway font_size_18 font_white uppercase">Signal Analysis Interface</p>
			</div>
		 
			<div id="linksContainer">
				<div id="link1">
					<img class="centerpic" src="images/radioastronomy.png" />
					<br />
					<p class="text_center type_raleway font_size_14 font_white uppercase"> Astronomy </p>
				</div>
				<div id="link2">
					<img class="centerpic" src="images/seti.png" />
					<br />
					<p class="text_center type_raleway font_size_14 font_white uppercase"> seti</p>
				</div>
				<div id="link3">
					<img class="centerpic" src="images/radiocomms.png" />
					<br />
					<p class="text_center type_raleway font_size_14 font_white uppercase"> Radio</p>
				</div>
			</div> 
		</div>
		<div id="middleRowContainer">

			<div id="GNUcontainer">
			</div>	
					<script type="text/javascript">
					g2 = new Dygraph(
						document.getElementById("GNUcontainer"),
						"temperatures.csv", // path to CSV file
						{}          // options
						);
				        </script>
			
			<div id="cameraContainer">
			The camera is not available at the moment 
			</div>

		</div>
		<div id="buttonContainer">

			<div id="recordingContainer">

			</div>
			<div id="analyzeDataContainer">

			</div>

			<div id="usersListContainer">

			</div>


			<div id="moveAntennaContainer">
			
					<!-- Custom Login/Register/Password Code  -->
					
					
					<div id="login-register-password">
					
						<ul class="tabs_login">
							<li class="active_login"><a href="#tab1_login">Login</a></li>
							<li><a href="#tab2_login">Register</a></li>
						</ul>
						<div class="tab_container_login">
							<div id="tab1_login" class="tab_content_login">
					
								<form method="post" action="login.php" class="wp-user-form">
									<div class="username">
										<label for="user_login">UserName: </label>
										<input type="text" name="log" value="" size="20" id="user_login" tabindex="11" />
									</div>
									<div class="password">
										<label for="user_pass">Password:</label>
										<input type="password" name="pwd" value="" size="20" id="user_pass" tabindex="12" />
									</div>
							
										<input type="submit" name="user-submit" value="Submit" tabindex="14" class="user-submit" />
										<input type="hidden" name="redirect_to" value="<?=$_SERVER['PHP_SELF']?>" />
										<input type="hidden" name="user-cookie" value="1" />
									</div>
								</form>
							</div>
							<div id="tab2_login" class="tab_content_login" style="display:none;">
								<form method="post" action="register.php" class="wp-user-form">
									<div class="login_fields">
										
										<input type="submit" name="user-submit" value="Register" class="user-submit" tabindex="103" />
										<input type="hidden" name="redirect_to" value="<?=$_SERVER['PHP_SELF']?>" />
										<input type="hidden" name="user-cookie" value="1" />
									</div>
								</form>
							</div>
							<div id="tab3_login" class="tab_content_login" style="display:none;">
								<p>Enter your username and email to reset your password.</p>
								<form method="post" action="resetpass.php" class="wp-user-form">
									<div class="username">
										<label for="user_login" class="hide"> Username: </label>
										<input type="text" name="user_login" value="" size="20" id="user_login" tabindex="1001" />
									</div>
									<div class="username">
										<label for="user_login" class="hide"> Email: </label>
										<input type="text" name="user_Email" value="" size="20" id="user_login" tabindex="1001" />
									</div>
									<div class="login_fields">
										
										<input type="submit" name="user-submit" value="Reset" class="user-submit" tabindex="1002" />
										<input type="hidden" name="redirect_to" value="<?=$_SERVER['PHP_SELF']?>" />
										<input type="hidden" name="user-cookie" value="1" />
									</div>
								</form>
							</div>
						</div>
					
					</div>
					
					<!-- Custom Login/Register/Password Code  -->
								
			</div>
		</div>
	</div>
	
	
	
	
	
  <div class="all_border_radio_25" id="sections_container">
</body>

</html>
