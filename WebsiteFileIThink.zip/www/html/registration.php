<?php 
include 'php/core/init.php'; 

 if (empty($_POST)==true) {
	$errors[] = 'No data receive';
} else {
	 if (user_exist($_POST['userN'])){
	 $errors[] = 'We are sorry, but that username is already exist';
	 }else{
	 
	$register_data = array(
		'user_id' => null,
		'first_name' =>$_POST['firstName'],
		'last_name' => $_POST['lastName'],
		'email'=> $_POST['e-mail'],
		'major'=> $_POST['Major'],
		'grade'=> $_POST['Grade'],
		'username'=> $_POST['userN'],
		'password'=> $_POST['pass'],
		'active'=> 1,
		'code_move' =>null,
		'authorize_by'=> null,);
	
	register_user($register_data);
	}
}


?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="css/main_site.css" />
	<script type="text/javascript"
	  src="dygraph-combined-dev.js"></script>
	<title>Welcome to CTU Radio Antenna Projects</title>
</head>


<body>
    
   <div class="all_border_radio_25" id="page_container">

<div id="maincontainer">
										<div id="TopContainer">
								
											<div id="logo">
												<img class="leftpic" src="images/cpt.png"/>
												
											</div>
											<div id="logoTitle">
												<p class="logo text_center type_raleway font_size_18 font_white uppercase">Capitol Technology University</p>
												<p class="logo text_center type_raleway font_size_18 font_white uppercase">Signal Analysis Interface</p>
											</div>
										 
											<div id="linksContainer">
												<div id="link1">
													<img class="centerpic" src="images/radioastronomy.png" />
													<br />
													<p class="text_center type_raleway font_size_14 font_white uppercase"> Astronomy </p>
												</div>
												<div id="link2">
													<img class="centerpic" src="images/seti.png" />
													<br />
													<p class="text_center type_raleway font_size_14 font_white uppercase"> seti</p>
												</div>
												<div id="link3">
													<img class="centerpic" src="images/radiocomms.png" />
													<br />
													<p class="text_center type_raleway font_size_14 font_white uppercase"> Radio</p>
												</div>
											</div> 
										</div>
		<div id="middleRowContainer">
		
			<?php if(empty($errors)) { ?>
					<div id="divider"></div>
				<p class="title4"> Great! you are now register.</p>
				
				<p class ="text">
				Please try to log in with the username and password you just created:</br>
				This will bring you to profile page where you can use the antenna.
				</p>
				   <? }else{?>
					<h2> We tried to log you in, but.....</h2>
					<?php
					echo output_errors($errors);
				    }
				?>
			
				
				
				
				
	
		</div>
		
		
</div>
	
	
  <div class="all_border_radio_25" id="sections_container">
</body>

</html>
