<?php

function update_user($update_data) {
	global $session_user_id;
	$update = array();
	array_walk($update_data, 'array_sanitize');
	foreach($update_data as $field=>$data){
		$update[] = '`' . $field . '` = \'' . $data . '\'';
        }
        mysql_query("UPDATE `registered` SET " . implode(', ', $update) . "WHERE `user_id` = $session_user_id");
        
}


function activate($my) {
	
	if(mysql_result(mysql_query("SELECT COUNT(`user_id`) FROM `members` WHERE `email_code` = $my AND `active`= 0"),0) == 1) {
		mysql_query("UPDATE `members` SET `active`= 1 WHERE `email_code` = $my");
		return true;
	}else if(mysql_result(mysql_query("SELECT COUNT(`user_id`) FROM `members` WHERE `email_code` = '$my' AND `active`= 1"),0) == 1){
		return true;
	}  else {
		return false;
	}
	
}
function change_password($user_id, $password) {
	$user_id = (int)$user_id;
	$password = $password;
	
	mysql_query("UPDATE `registered` SET `password` = '$password' WHERE `user_id` = $user_id");
}
function register_user($register_data) {
	
	array_walk($register_data, 'array_sanitize');
	
	if (count($register_data) > 0) {
		foreach ($register_data as $key => $value) {
			
			$value1 = mysql_real_escape_string($value);
			if(is_numeric($value1) && is_int(($value1 + 0))) { 
				$updates[] = $value1;
			} else {
				$updates[] = "'$value1'";
			}
			
			$key = mysql_real_escape_string($key); 
			$updates2[] = $key;
		}
        }
        $implodeArray = implode(',',$updates);
        $fields = implode(',',$updates2);
        mysql_query("INSERT INTO `members` ($fields) VALUES($implodeArray)");
}
function register_user_final($register_data) {
	
	array_walk($register_data, 'array_sanitize');
	
	if (count($register_data) > 0) {
		foreach ($register_data as $key => $value) {
			
			$value1 = mysql_real_escape_string($value);
			if(is_numeric($value1) && is_int(($value1 + 0))) { 
				$updates[] = $value1;
			} else {
				$updates[] = "'$value1'";
			}
			
			$key = mysql_real_escape_string($key); 
			$updates2[] = $key;
		}
        }
        $implodeArray = implode(',',$updates);
        $fields = implode(',',$updates2);
        mysql_query("INSERT INTO `registered` VALUES($implodeArray)");
}

function register_user_update($register_data) {
	
	array_walk($register_data, 'array_sanitize');
	
	if (count($register_data) > 0) {
		foreach ($register_data as $key => $value) {
			
			$value1 = mysql_real_escape_string($value);
			if(is_numeric($value1) && is_int(($value1 + 0))) { 
				$updates[] = $value1;
			} else {
				$updates[] = "'$value1'";
			}
			
			$key = mysql_real_escape_string($key); 
			$updates2[] = $key;
		}
        }
        $implodeArray = implode(',',$updates);
        $fields = implode(',',$updates2);
        mysql_query("INSERT INTO registered VALUES($implodeArray)");
}
function user_count() {
	return mysql_result(mysql_query("SELECT COUNT(`user_id`) FROM `members` WHERE `active` = 1"),0);
}
function user_data($user_id) {
	$data = array();
	$user_id = (int)$user_id;
	
	$func_num_args = func_num_args();
	$func_get_args = func_get_args();
	
	if($func_num_args >1) {
		unset($func_get_args[0]);
		
		$fields = '`' . implode('`,`', $func_get_args) . '`';
		$data = mysql_fetch_assoc(mysql_query("SELECT '$fields' FROM `registered` WHERE `user_id` = '$user_id'"));
		return $data;
		
	}	  
	
}
function logged_in() {
	$re=null;
	//echo empty($_SESSION['user_id']);
	if(empty($_SESSION['user_id'])===true){
		$re=false;
	}else {
		$re=true;
		}
		return $re;
}

function user_exists($username) {
	
	$query = mysql_query("SELECT `user_id` FROM `members` WHERE `username` = '$username'");
	
	if(mysql_num_rows($query)>0){
		return true;
	}else{
		return false;
	}
	
}
function email_exists($email) {
	$email = sanitize($email);
	$query = mysql_query("SELECT COUNT(`user_id`) FROM `members` WHERE `email` = '$email'");
	return (mysql_result($query,0) === 1) ? true : false;
}

function user_active($username) {
	$username = sanitize($username);
	$query = mysql_query("SELECT COUNT(`user_id`) FROM `registered` WHERE `username` = '$username' AND `active` = 1");
	return (mysql_result($query,0) === 1) ? true : false;
}
function user_id_from_username($username) {
	$username = sanitize($username);
	$query=mysql_query("SELECT `user_id` FROM `members` WHERE `username` = '$username'");
	if(mysql_num_rows($query)>0){
		$u=mysql_result($query,0,"user_id") or die (mysql_error());
		
		return $u;
	}else{return 0;}
	
}
function user_id_from_email($email) {
	return (mysql_result(mysql_query("SELECT `user_id` FROM `members` WHERE `email` = '$email'"),0));
}
function login($username, $password) {
	//$user_id = user_id_from_username($username);
    	// $q = mysql_result(mysql_query("SELECT  FROM  WHERE "),0,0);
    	$response=null;
    	$name=mysql_real_escape_string($username);
    	$password=mysql_real_escape_string($password);
    	
	$query=mysql_query("SELECT `user_id` FROM `members` WHERE `username` = '$username' AND `password` = '$password'");
	
	if(mysql_num_rows($query)>0){return true;}else{return false;}
	
}


function activation_number($id){
	$id = sanitize($id);
	
	$query=mysql_query("SELECT `active` FROM `members` WHERE `user_id` = '$id'");
	if(mysql_num_rows($query)>0){
	
		$u=mysql_result($query,0);

		return $u;
	}else{return 0;}
}
function email_r($id){
	return (mysql_result(mysql_query("SELECT `email` FROM `members` WHERE `user_id` = '$id'"),0));     
}
function lastname($id){
	return (mysql_result(mysql_query("SELECT `last_name` FROM `members` WHERE `user_id` = $id"),0));     
}
function firstname($id){
	$query=mysql_query("SELECT `first_name` FROM `members` WHERE `user_id` = '$id'");
	if(mysql_num_rows($query)>0){
		$fn=mysql_result($query,0);
		return $fn;
	}else{return 0;}    
}

function grade($id){
	return ( mysql_result(mysql_query("SELECT `grade` FROM `members` WHERE `user_id` = $id"),0));     
}
function usern($id){
	return ( mysql_result(mysql_query("SELECT `username` FROM `members` WHERE `user_id` = '$id'"),0)); 
}
function passw($id){
	return ( mysql_result(mysql_query("SELECT `password` FROM `members` WHERE `user_id` = $id"),0)); 
}
function atv($id){
	return ( mysql_result(mysql_query("SELECT `active` FROM `members` WHERE `user_id` = $id"),0)); 
}
function get_people(){
	mysql_query("SELECT * FROM `registered`");
}



//antenna table fumctions
function check_date_time($d,$t){
	$query=mysql_query("SELECT `user_id` FROM `antenna` WHERE `date` = '$d' AND `time` = '$t'");
	if(mysql_num_rows($query)>0){return true;}else{return false;}
}

function first_time_user($id){
$query=mysql_query("SELECT `UseId` FROM `antenna` WHERE `user_id` = '$id'");
	if(mysql_num_rows($query)>0){return false;}else{return true;}
}

function register_user_antenna($register_data) {
	
	array_walk($register_data, 'array_sanitize');
	
	if (count($register_data) > 0) {
		foreach ($register_data as $key => $value) {
			
			$value1 = mysql_real_escape_string($value);
			if(is_numeric($value1) && is_int(($value1 + 0))) { 
				$updates[] = $value1;
			} else {
				$updates[] = "'$value1'";
			}
			
			$key = mysql_real_escape_string($key); 
			$updates2[] = $key;
		}
        }
        $implodeArray = implode(',',$updates);
        $fields = implode(',',$updates2);
        mysql_query("INSERT INTO `antenna` ($fields) VALUES($implodeArray)");
}

function update_date_time($id,$date,$t){
	$user_id = (int)$id;
	mysql_query("UPDATE `antenna` SET `date` = '$date' ,`time`='$t' WHERE `user_id` = '$user_id'");
}

//update members 


function update_code_authorization($id,$c,$a){
$user_id = (int)$id;
	mysql_query("UPDATE `members` SET `code_move` = '$c' ,`authorize_by`='$a' WHERE `user_id` = '$user_id'");
}
?>