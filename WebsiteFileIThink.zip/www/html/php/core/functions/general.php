<?php
function logged_in_redirect() {
   if (logged_in() === true) {
   	   $active=activation_number($_SESSION['user_id']);
		  
   	   	if ($active==1){
				    //members();
			 ?>
			 <meta HTTP-EQUIV="REFRESH" content="0; url=http://localhost/FUMA/UserProfile.php">
			 <?php
			 exit();	
		}else if($active==2){
  				   //staff();
		         ?>
			 <meta HTTP-EQUIV="REFRESH" content="0; url=http://localhost/FUMA/FacultyProfile.php">
			 <?php
			 exit();	
		}
   	}
}
function redirect_home() {
 $active=activation_number($_SESSION['user_id']);
	if ($active==1){
			 $resul= "UserProfile.php";
	}else if($active==2){
			 $resul= "FacultyProfile.php";
	}
	return($resul);
}
function protect_page() {
    if (logged_in() === false) {
	 ?>
	 <meta HTTP-EQUIV="REFRESH" content="0; url=http://localhost/FUMA/Main.php">
	 <?php
	  exit();
	 }
	 
}
function go_home()
{ 
if (logged_in() === false) {
header('Location: main.php');
	 exit();
}
}

function getcode($var)
 {
 
  $var  = parse_url($var, PHP_URL_QUERY);
  $var  = html_entity_decode($var);
  $arr  = array();
  $var  = explode('&',$var);

  foreach($var as $val)
   {
    $x          = explode('=', $val);
    $arr[$x[0]] = $x[1];
     
   } 
  unset($val,$x,$var);
    foreach($arr as $value)
   {

     $code = $value;
   }
   return $code;
 }

function array_sanitize(&$item) {
  $item = htmlentities(strip_tags(mysql_real_escape_string($item)));
}
function sanitize($data) {
 return htmlentities(strip_tags(mysql_real_escape_string($data)));
}
function output_errors($errors) {
     $output = array();
	 foreach($errors as $error){
	    $output[] = '<li>' . $error . '</li>';
	 }
	 return '<ul>' . implode('', $output) . '</ul>';
}
?>