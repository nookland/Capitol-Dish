<?php
$connect_error = 'sorry experiencing connection problems.';
$link = mysql_connect('localhost','root','ctu123') or die($connect_error);
mysql_select_db('users',$link)or die($connect_error);
?>
