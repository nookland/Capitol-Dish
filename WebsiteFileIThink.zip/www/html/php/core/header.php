<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<!-- the icono va aqui -->
		<link rel="icon" type="icon" href="files/pictures/icono.ico"></link>
		<!-- the keywords go here -->
		<meta name="keywords" content=" "/>
		<!-- the description goes here -->
		<meta name="description" content=" "/>			
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<!-- titulo-->
		<title>IYDF | International Youth Dynamics Foundation  </title>
		<!--stylesheets-->
		<link href="files/css/user_style.css"rel="stylesheet" type="text/css" media="screen" />
		<?php include'files/php/fragments/fonts.php'; ?>		
	</head>
	<!--body of the HTML-->
	<body>
		<div id="container">
			<div id="middle">
			