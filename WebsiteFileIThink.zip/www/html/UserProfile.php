<?php include 'php/core/init.php'; 
	
	$Fname= firstname($_SESSION['user_id']);
	$Lname=lastname($_SESSION['user_id']);
	
	if (isset($_POST['DT'])==true) {
		$d= $_POST['startdate'];
		$t= $_POST['starttime'];
		$authorize=$_POST['authorize'];
		
		
		list($m, $d, $y) = explode("/", $d);
		
		$date.=$y; 
		$date.="-";
		$date.=$m;
		$date.="-";
		$date.=$d;
		
		
	 if (check_date_time($date,$t)){
		$errors[] = 'We are sorry but '.$t.' is already taken.';
	}else{
	 
		//create the code 
		$r=rand(0, 9999);
		$code=$Fname[0].$Lname[0].$r;
	
		//update the antena table 
		if(first_time_user($_SESSION['user_id'])){
			$register_use= array(
		'UseId' => null,
		'usur_id' =>$_SESSION['user_id'],
		'date' => $date,
		'time'=> $t,
		'authorize'=>  null,);
	
		register_user_antenna($register_data);
		}else {
			update_date_time($_SESSION['user_id'],$date,$t);
		}
		//update the memebrs table code
		
		 update_code_authorization($_SESSION['user_id'],$code,$authorize);
		
		//provide the code
		print '<script type="text/javascript">';
		print 'alert("Make note of this code : '. $code.'\nYou will need it in order to mve the antenna once you are authorize")';
		print '</script>'; 
	}
	
}else if (isset($_POST['MA'])==true) {
				$comPort="/dev/ttyACM0";
				$degree = $_POST["degree"];
				$direction=$_POST["direction"];
		
					if($direction == "west"){
	
   	     
							if (($fp = fopen($comPort, "w+")) !== false) { 
							fwrite($fp,'W');   
							fclose($fp); 
							}
			}else if($direction=="east"){
						if (($fp = fopen($comPort, "w+")) !== false) { 
							fwrite($fp, 'E');   
								 fclose($fp); 
								 }
	//echo $direction;
					}

if(strlen($degree)==1){
	
	if(intval($degree)===0){
			//echo "inside one"; 
				if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A0'); 
						fclose($fp);
					}
   	} else if(intval($degree)===1){
			//echo "inside one"; 
				if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A1'); 
						fclose($fp);
					}
   	} else if(intval($degree)===2){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A2'); 
						fclose($fp);
					}
   	}else if(intval($degree)===3){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A3'); 
						fclose($fp);
					}
   	}else if(intval($degree)===4){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A4'); 
						fclose($fp);
					}
   	}else if(intval($degree)===5){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A5'); 
						fclose($fp);
					}
   	}else if(intval($degree)===6){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A6'); 
						fclose($fp);
					}
   	}else if(intval($degree)===7){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A7'); 
						fclose($fp);
					}
   	}else if(intval($degree)===8){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A8'); 
						fclose($fp);
					}
   	}else if(intval($degree)===9){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A9'); 
						fclose($fp);
					}
   	}
   //fclose($fp);
    //echo $value;
}else if(strlen($degree)==2){
	 
	 $degree1= $degree[0];
	 $degree2= $degree[1];
	 
	if(intval($degree1)===0){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC0'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===1){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC1'); 
						fclose($fp);
					}
   	} else if(intval($degree1)===2){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC2'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===3){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC3'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===4){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC4'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===5){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC5'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===6){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC6'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===7){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC7'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===8){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC8'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===9){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC9'); 
						fclose($fp);
					}
   	}
   	
   	if(intval($degree2)===0){
   	   if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD0'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===1){
   	   if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD1'); 
						fclose($fp);
					}
   	} else if(intval($degree2)===2){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD2'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===3){
   	   if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD3'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===4){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD4'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===5){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD5'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===6){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD6'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===7){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD7'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===8){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD8'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===9){
   	   if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD9'); 
						fclose($fp);
					}
   	}
   	exit;
	
}else if(strlen($degree)==3){
	 
	 $degree1= $degree[0];
	 $degree2= $degree[1];
	 $degree3= $degree[2];
	 
	if(intval($degree1)===0){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG0'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===1){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG1'); 
						fclose($fp);
					}
   	} else if(intval($degree1)===2){
   	       	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG2'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===3){
   	       	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG3'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===4){
   	       	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG4'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===5){
   	     	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG5'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===6){
   	     	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG6'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===7){
   	       	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG7'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===8){
   	        	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG8'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===9){
   	       	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG9'); 
						fclose($fp);
					}
   	}
   	
   	if(intval($degree2)===0){
   	      	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH0'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===1){
   	      	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH1'); 
						fclose($fp);
					}
   	} else if(intval($degree2)===2){
   	       if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH2'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===3){
   	        if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH3'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===4){
   	       if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH4'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===5){
   	        if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH5'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===6){
   	       if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH6'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===7){
   	      if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH7'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===8){
   	       if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH8'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===9){
   	        if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH9'); 
						fclose($fp);
					}
   	}
	
   	if(intval($degree3)===0){
   	      if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI0'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===1){
   	      if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI1'); 
						fclose($fp);
					}
   	} else if(intval($degree3)===2){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI2'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===3){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI3'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===4){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI4'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===5){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI5'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===6){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI6'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===7){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI7'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===8){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI8'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===9){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI9'); 
						fclose($fp);
					}
   	}
	exit;
	
	
}
}
?>
<html>

<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="css/main_site.css" />
<script type="text/javascript"src="dygraph-combined-dev.js"></script>
 <script language="javascript" src="js/registrationValidate.js"></script>
   <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  
   <script type="text/javascript" src="js/jquery.timepicker.js"></script>
  <link rel="stylesheet" type="text/css" href="css/jquery.timepicker.css" />
  
<title>Welcome to CTU Radio Antenna Projects</title>
<head>

<body>
    
   <div class="all_border_radio_25" id="page_container">

<div id="maincontainer">
										<div id="TopContainer">
								
											<div id="logo">
												<a href =Main.php><img class="leftpic" src="images/cpt.png"/></a>
												
											</div>
											<div id="logoTitle">
												<p class="logo text_center type_raleway font_size_18 font_white uppercase">Capitol Technology University</p>
												<p class="logo text_center type_raleway font_size_18 font_white uppercase">Signal Analysis Interface</p>
											</div>
										 
											<div id="linksContainer">
												<div id="link1">
													<img class="centerpic" src="images/radioastronomy.png" />
													<br />
													<p class="text_center type_raleway font_size_14 font_white uppercase"> Astronomy </p>
												</div>
												<div id="link2">
													<img class="centerpic" src="images/seti.png" />
													<br />
													<p class="text_center type_raleway font_size_14 font_white uppercase"> seti</p>
												</div>
												<div id="link3">
													<img class="centerpic" src="images/radiocomms.png" />
													<br />
													<p class="text_center type_raleway font_size_14 font_white uppercase"> Radio</p>
												</div>
											</div> 
										</div>
		<div id="middleRowContainer2">

			<div id="divider"></div>
			
				
				<p class="title4"> Wellcome <?php echo $Fname;?>  <?php echo $Lname;?>  </p>
				<div id="divider"></div>
				<p class="title3"> Select an available date and time to use the antenna</p>
				
					</br>
					<form method="POST" action="UserProfile.php" onsubmit="return checkForm(this);">
						<fieldset>
							<legend>Pick the Date and Time</legend>
								<label>Start Date: <input type="text" size="12"  name="startdate"  id="datepicker"></label>
								<label>Start Time: <input type="text" size="12"  name="starttime" id="scrollDefaultExample"></label>
								<label>Authorize By:<select id="authorize" name="authorize">
												<option value="Conner">Professor Conor</option>
												<option value="Antunner">Professor Antunnes</option>
												</select>
								

								<input type="Submit" name ="DT" value="Select">
						</fieldset>
					</form>
					<?php if(empty($errors)){
						}else{
					?>
					<h2> Please Select Again....</h2>
					<?php
					echo output_errors($errors);
				    }
				?>
				<div id="divider"></div>
					<p class="title2"> Use the antenna</p>	
					<p class="title3"> The antenna can only be moved from 0 -110 in the West direction </p>
					<p class="title3"> The antenna can only be moved from 0 -110 in the East direction </p>
				<form method="POST" action="UserProfile.php" onsubmit="return checkForm2(this);">
						<fieldset>
							<legend>Enter Code</legend>
								<label>Code: <input type="text" size="12"  name="code"></label>
								<label>Degree: <input type="text" size="12"  name="degree"></label>
								<label>Direction:<select id="d" name="direction">
												<option value="west">West</option>
												<option value="east">East</option>
												</select>
								

								<input type="Submit" name ="MA" value="Select">
						</fieldset>
				</form>
					
					
					
					
					
					
					
					
					
		</div>
		
		
</div>
	
	
  <div class="all_border_radio_25" id="sections_container">
</body>

</html>
<script type="text/javascript">

  function checkForm(form)
  {
    if(!checkDate(form.startdate)) return false;
    if(!checkTime(form.starttime)) return false;
    return true;
  }
  
  function checkForm2(form)
  {
    if(!checkDate(form.startdate)) return false;
    if(!checkTime(form.starttime)) return false;
    return true;
  }
  
  
</script>
  <script>
  $(function() {
    $( "#datepicker" ).datepicker({ beforeShowDay: $.datepicker.noWeekends });
  });
  </script>
 
<script>
	$(function(){
                    $('#scrollDefaultExample').timepicker({
    'minTime': '9:00am',
    'maxTime': '9:30pm',
    'showDuration': false
});
});
</script>

