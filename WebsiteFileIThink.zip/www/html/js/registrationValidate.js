/*
This is the JavaScript file
Created: Obtober 1, 2014
Last updated: October 6, 2014
By: Erlin Cruz 
*/
//global array variable to hold the erros found in the form.
var errors=new Array();
//this flag test to see if there were any errors found.
var flag=0;
//global vaible that counts how many error were display during each round of the script.
var countrow=0;

//function that call the display erros funtion to check for errros and stop the page from sending info.
//to the server if any erros are found.
function validateForm(event)
{
	errors.length=0;
	display_errors();
	
	//if there are errors stop the page otherwise continue 
	if(flag==1)event.preventDefault();	
}

/*
function to see if the username has at least five character and is those characters 
are alpha-characters.
*/
function check_username()
{
	
	var Uname = document.getElementById("username");
	var UnameInput = Uname.value;
	var count=0;
	if( UnameInput.length < 5 )
		errors.push("The username should have at least 5 characters.");	
	for(var i=0;i<UnameInput.length;i++)
	{	
		var r=UnameInput.substring(i,i+1);
		var h = parseInt(r);
		if(isNaN(h))count++;
	}
	
	if(count<5)
		errors.push("The username should have at least 5 alpha-characters.");
	//clear the variable so that the user can enter new data.
	UnameInput="";
}

/*
function to see if the passwords enter match, 
if the password has more than one character and if the password has 
at least one alphe-character.
*/
function check_passwords()
{
	var passw1= document.getElementById("password");	
	var PasswInput1=passw1.value;
	
	var count1=0;
	
	for(var a=0;a<PasswInput1.length;a++)
	{
		
		var f=PasswInput1.substring(a,a+1);
		var d = parseInt(f);
		if(isNaN(d))count1++;
	}
	
	if(count1<1)
		errors.push("The password should have at least 1 alpa-characters.");	
	
	if( PasswInput1.length < 1 )
		errors.push("The password should have at least 1 characters.");	
		
	//clears the variables so that the user can enter new data when s/he try to fix the problem.
	PasswInput1="";
	
	
}
/*
function to see if the email enter contains the character "@"
*/
function check_email(){
	
	var Email=document.getElementById("email");
	var EmailInput=Email.value;
	var f=EmailInput.indexOf("@");
	
	if(f=="0" || f=="-1"){
		errors.push("This is an invalid email address.");			
	}
	//clear the variable so it can hold new data 	
	EmailInput="";
}

function check_Authorization(){
	var autho= document.getElementById("authorize");	
	var authorization=autho.value;
	var count=0;
	if( authorization.length < 3 ){
		errors.push("You need to pick the person that authorize you to use the antenna.");	
	}
	authorization="";
}

/*
function calls all of the other functions that are conducting the differnt 
tests to the data passed from the form.

it collects the errors and creates a table that is display above the form.

it sets the flag to tell the script if there were any errors 
*/
function display_errors()
{
	
	check_username();
	check_passwords();
	check_email();
	check_Authorization();
	
	if (countrow>0){
		clean_errors_table();
	}	
	if(errors.length > 0){
		var div=document.getElementById("error");
		var tableElement = document.createElement("table");
		tableElement.className="display_errors"; 
		tableElement.id="display";
		
		for(var i=0;i<errors.length;i++){
			var tr = document.createElement("tr");
			var td = document.createElement("td");
			
			td.innerHTML = errors[i];
			
			tr.appendChild(td);
			tableElement.appendChild(tr);
			countrow++
		}
		
		div.appendChild(tableElement);
		flag=1;
		errors.length=0;
	}else{
		flag=0;
	}
	
}
/*
function delets the erros table created in the display funtion every time there were any errors found 
*/
function clean_errors_table(){
	
	var div1=document.getElementById("error");
	var tableElement1=document.getElementById("display");
	div1.removeChild(tableElement1);
}

/*
this funtion checks for the date validation in the user profile page.
*/

 function checkDate(field)
  {
    var allowBlank = true;
    var minYear = 2014;
    var maxYear = (new Date()).getFullYear();

    var errorMsg = "";

    // regular expression to match required date format
    re = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;

    if(field.value != '') {
      if(regs = field.value.match(re)) {
        if(regs[1] < 1 || regs[1] > 12) {
          errorMsg = "Invalid value for month: " + regs[1];
        } else if(regs[2] < 1 || regs[2] > 31) {
          errorMsg = "Invalid value for day: " + regs[2];
        } else if(regs[3] < minYear || regs[3] > maxYear) {
          errorMsg = "Invalid value for year: " + regs[3] + " - must be between " + minYear + " and " + maxYear;
        }
      } else {
        errorMsg = "Invalid date format: " + field.value;
      }
    } else if(!allowBlank) {
      errorMsg = "Empty date not allowed!";
    }

    if(errorMsg != "") {
      alert(errorMsg);
      field.focus();
      return false;
    }

    return true;
  }
/*
this funtion checks for the time validation in the user profile page.
*/
  function checkTime(field)
  {
    var errorMsg = "";

    // regular expression to match required time format
    re = /^(\d{1,2}):(\d{2})(:00)?([ap]m)?$/;

    if(field.value != '') {
      if(regs = field.value.match(re)) {
        if(regs[4]) {
          // 12-hour time format with am/pm
          if(regs[1] < 1 || regs[1] > 12) {
            errorMsg = "Invalid value for hours: " + regs[1];
          }
        } else {
          // 24-hour time format
          if(regs[1] > 23) {
            errorMsg = "Invalid value for hours: " + regs[1];
          }
        }
        if(!errorMsg && regs[2] > 59) {
          errorMsg = "Invalid value for minutes: " + regs[2];
        }
      } else {
        errorMsg = "Invalid time format: " + field.value;
      }
    }

    if(errorMsg != "") {
      alert(errorMsg);
      field.focus();
      return false;
    }

    return true;
  }
/*
function initializes the script so it recognize the html elemennts use within the script.
*/
function initialize( )
{
	
}

window.onload = initialize;
