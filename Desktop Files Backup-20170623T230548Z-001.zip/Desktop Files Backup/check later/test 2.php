<?php


$verz="1.0";
//$comPort = "/dev/ttyACM0"; /*change to correct com port */
$comPort="/dev/cu.usbmodemFD121";
if (isset($_POST["degree"])) {
$degree = $_POST["degree"];
$direction=$_POST["direction"];
//echo"hello";
//echo $degree;
if($direction == "west"){
	//$fp = fopen($comPort, "w+");
	 //    fwrite($fp,1); /* this is the number that it will write */
   	 //    fclose($fp);
   	     
   	 if (($fp = fopen($comPort, "a")) !== false) { 
   	 fwrite($fp, 'W');   
   	 fclose($fp); 
  	 }
   	     //echo $direction;
}else if($direction=="east"){
	 if (($fp = fopen($comPort, "a")) !== false) { 
   	 fwrite($fp, 'E');   
   	 fclose($fp); 
  	 }
	//echo $direction;
}

if(strlen($degree)==1){
     $fp =fopen($comPort, "w+");
     echo $degree;
	if(intval($degree)===1){
		echo "inside one"; 
		if (($fp = fopen($comPort, "w+")) !== false) { 
			echo "inside if ";
			fwrite($fp,1);   
			fclose($fp); 
			}
   	     //fwrite($fp,1); /* this is the number that it will write */
   	     //fclose($fp);
   	} else if(intval($degree)===2){
   	     fwrite($fp,2); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree)===3){
   	     fwrite($fp,3); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree)===4){
   	     fwrite($fp,4); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree)===5){
   	     fwrite($fp,5); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree)===6){
   	     fwrite($fp,6); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree)===7){
   	     fwrite($fp,7); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree)===8){
   	     fwrite($fp,8); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree)===9){
   	     fwrite($fp,9); /* this is the number that it will write */
   	     fclose($fp);
   	}
   	exit;
    //echo $value;
}else if(strlen($degree)==2){
    
	
	 $fp =fopen($comPort, "w+");
	 
	 $degree1= $degree[0];
	 $degree2= $degree[1];
	 
	if(intval($degree1)===1){
   	     fwrite($fp,1); /* this is the number that it will write */
   	     fclose($fp);
   	} else if(intval($degree1)===2){
   	     fwrite($fp,2); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===3){
   	     fwrite($fp,3); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===4){
   	     fwrite($fp,4); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===5){
   	     fwrite($fp,5); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===6){
   	     fwrite($fp,6); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===7){
   	     fwrite($fp,7); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===8){
   	     fwrite($fp,8); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===9){
   	     fwrite($fp,9); /* this is the number that it will write */
   	     fclose($fp);
   	}
   	
   	if(intval($degree2)===1){
   	     fwrite($fp,1); /* this is the number that it will write */
   	     fclose($fp);
   	} else if(intval($degree2)===2){
   	     fwrite($fp,2); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===3){
   	     fwrite($fp,3); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===4){
   	     fwrite($fp,4); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===5){
   	     fwrite($fp,5); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===6){
   	     fwrite($fp,6); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===7){
   	     fwrite($fp,7); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===8){
   	     fwrite($fp,8); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===9){
   	     fwrite($fp,9); /* this is the number that it will write */
   	     fclose($fp);
   	}
   	exit;
	
}else if(strlen($degree)==3){
    
	
	 $fp =fopen($comPort, "w+");
	 
	 $degree1= $degree[0];
	 $degree2= $degree[1];
	 $degree3= $degree[2];
	 
	if(intval($degree1)===1){
   	     fwrite($fp,1); /* this is the number that it will write */
   	     fclose($fp);
   	} else if(intval($degree1)===2){
   	     fwrite($fp,2); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===3){
   	     fwrite($fp,3); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===4){
   	     fwrite($fp,4); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===5){
   	     fwrite($fp,5); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===6){
   	     fwrite($fp,6); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===7){
   	     fwrite($fp,7); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===8){
   	     fwrite($fp,8); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree1)===9){
   	     fwrite($fp,9); /* this is the number that it will write */
   	     fclose($fp);
   	}
   	
   	if(intval($degree2)===1){
   	     fwrite($fp,1); /* this is the number that it will write */
   	     fclose($fp);
   	} else if(intval($degree2)===2){
   	     fwrite($fp,2); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===3){
   	     fwrite($fp,3); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===4){
   	     fwrite($fp,4); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===5){
   	     fwrite($fp,5); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===6){
   	     fwrite($fp,6); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===7){
   	     fwrite($fp,7); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===8){
   	     fwrite($fp,8); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree2)===9){
   	     fwrite($fp,9); /* this is the number that it will write */
   	     fclose($fp);
   	}
	
   	if(intval($degree3)===1){
   	     fwrite($fp,1); /* this is the number that it will write */
   	     fclose($fp);
   	} else if(intval($degree3)===2){
   	     fwrite($fp,2); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree3)===3){
   	     fwrite($fp,3); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree3)===4){
   	     fwrite($fp,4); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree3)===5){
   	     fwrite($fp,5); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree3)===6){
   	     fwrite($fp,6); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree3)===7){
   	     fwrite($fp,7); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree3)===8){
   	     fwrite($fp,8); /* this is the number that it will write */
   	     fclose($fp);
   	}else if(intval($degree3)===9){
   	     fwrite($fp,9); /* this is the number that it will write */
   	     fclose($fp);
   	}
	exit;
	
	
}
echo "finish sending";
}else{




?>
<html>
<body>

<center><h1>Arduino from PHP Example 1</h1><b>Version <?php echo $verz; ?></b></center>

<form method="post" action="<?=$_SERVER['PHP_SELF']?>">



Degree: <input type="text" name="degree"><br>
Direction: <select name="direction">
		<option value="west">WEST</option>
		<option value="east">EAST</option></select><br>
<input type="submit">
</form>
<br />

<br />

<br />
<br />
<br />
<br />


</body>
</html>
<?}?>