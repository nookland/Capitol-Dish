# include "stdafx.h"
using namespace System;
using namespace System::IO::Ports;

int main(array<System::String > args)
{
	Console::WriteLine("Visual C++ Program Output:");
	if(args->Length==2)
	{
		String message=args[1]; // get message ( 0 or 1 )
		String port=args[0]; // get port name
		
		
		// arduino settings
		SerialPort arduino;
		arduino = gcnew SerialPort(); // make arduino object
		arduino->PortName =port; // set port name
		arduino->BaudRate = 9600; // set baud rate
		arduino->ReadTimeout = 500; // set read time out
		arduino->WriteTimeout = 500; // set write time out
		// open port
		try
		{
			arduino->Open(); // open port
				//check that user typed one of the options
				if(String::Compare(message,"on")==0) // if sent value was "on"
					arduino->Write("1"); // send 1 to arduino
				else if(String::Compare(message,"off")==0)
					arduino->Write("0"); // send 0 to arduino
				else
					Console::WriteLine(message+" was not an option");
			// close port to arduino
			arduino->Close();
		}
		catch (IO::IOException e  ) 
		{ 
			Console::WriteLine(e->GetType()->Name+": Port is not ready");
			return 2;
		}
		catch (ArgumentException e)
		{
			Console::WriteLine(e->GetType()->Name+": incorrect port name syntax, must start with COM/com");
			return 3;
		}

	}
	else
	{
		Console::WriteLine("Error: arduino.exe needs at least two parameters.");
		return 1;
	}

    return 0;
}