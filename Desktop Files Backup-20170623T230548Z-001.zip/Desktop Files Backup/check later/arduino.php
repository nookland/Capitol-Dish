<? 
$message=$_POST['message'];
$port=$_POST['port'];


exec("arduino.exe {$port} {$message}",$output,$returnStatus);

foreach($output as $line) {
 echo '<p>';
 echo $line;
 echo '</p>';
}
echo "Return Status: {$returnStatus}";
?>