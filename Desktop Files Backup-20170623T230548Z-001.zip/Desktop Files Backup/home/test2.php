<?php
$verz="1.0";
//$comPort = "/dev/ttyACM0"; /*change to correct com port */
$comPort="/dev/ttyACM1";;
if (isset($_POST["degree"])) {
$degree = $_POST["degree"];
$direction=$_POST["direction"];
//echo"hello";
//echo $degree;
if($direction == "west"){
	//$fp = fopen($comPort, "w+");
	 //    fwrite($fp,1); /* this is the number that it will write */
   	 //    fclose($fp);
   	     
   	 if (($fp = fopen($comPort, "w+")) !== false) { 
   	 fwrite($fp,'W');   
   	 fclose($fp); 
  	 }
   	     //echo $direction;
}else if($direction=="east"){
	 if (($fp = fopen($comPort, "w+")) !== false) { 
   	 fwrite($fp, 'E');   
   	 fclose($fp); 
  	 }
	//echo $direction;
}

if(strlen($degree)==1){
	
	if(intval($degree)===0){
			//echo "inside one"; 
				if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A0'); 
						fclose($fp);
					}
   	} else if(intval($degree)===1){
			//echo "inside one"; 
				if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A1'); 
						fclose($fp);
					}
   	} else if(intval($degree)===2){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A2'); 
						fclose($fp);
					}
   	}else if(intval($degree)===3){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A3'); 
						fclose($fp);
					}
   	}else if(intval($degree)===4){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A4'); 
						fclose($fp);
					}
   	}else if(intval($degree)===5){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A5'); 
						fclose($fp);
					}
   	}else if(intval($degree)===6){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A6'); 
						fclose($fp);
					}
   	}else if(intval($degree)===7){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A7'); 
						fclose($fp);
					}
   	}else if(intval($degree)===8){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A8'); 
						fclose($fp);
					}
   	}else if(intval($degree)===9){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'A9'); 
						fclose($fp);
					}
   	}
   //fclose($fp);
    //echo $value;
}else if(strlen($degree)==2){
	 
	 $degree1= $degree[0];
	 $degree2= $degree[1];
	 
	if(intval($degree1)===0){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC0'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===1){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC1'); 
						fclose($fp);
					}
   	} else if(intval($degree1)===2){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC2'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===3){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC3'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===4){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC4'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===5){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC5'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===6){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC6'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===7){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC7'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===8){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC8'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===9){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BC9'); 
						fclose($fp);
					}
   	}
   	
   	if(intval($degree2)===0){
   	   if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD0'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===1){
   	   if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD1'); 
						fclose($fp);
					}
   	} else if(intval($degree2)===2){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD2'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===3){
   	   if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD3'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===4){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD4'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===5){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD5'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===6){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD6'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===7){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD7'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===8){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD8'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===9){
   	   if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'BD9'); 
						fclose($fp);
					}
   	}
   	exit;
	
}else if(strlen($degree)==3){
	 
	 $degree1= $degree[0];
	 $degree2= $degree[1];
	 $degree3= $degree[2];
	 
	if(intval($degree1)===0){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG0'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===1){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG1'); 
						fclose($fp);
					}
   	} else if(intval($degree1)===2){
   	       	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG2'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===3){
   	       	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG3'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===4){
   	       	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG4'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===5){
   	     	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG5'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===6){
   	     	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG6'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===7){
   	       	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG7'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===8){
   	        	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG8'); 
						fclose($fp);
					}
   	}else if(intval($degree1)===9){
   	       	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FG9'); 
						fclose($fp);
					}
   	}
   	
   	if(intval($degree2)===0){
   	      	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH0'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===1){
   	      	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH1'); 
						fclose($fp);
					}
   	} else if(intval($degree2)===2){
   	       if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH2'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===3){
   	        if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH3'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===4){
   	       if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH4'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===5){
   	        if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH5'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===6){
   	       if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH6'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===7){
   	      if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH7'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===8){
   	       if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH8'); 
						fclose($fp);
					}
   	}else if(intval($degree2)===9){
   	        if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FH9'); 
						fclose($fp);
					}
   	}
	
   	if(intval($degree3)===0){
   	      if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI0'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===1){
   	      if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI1'); 
						fclose($fp);
					}
   	} else if(intval($degree3)===2){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI2'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===3){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI3'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===4){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI4'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===5){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI5'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===6){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI6'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===7){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI7'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===8){
   	     if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI8'); 
						fclose($fp);
					}
   	}else if(intval($degree3)===9){
   	    if (($fp = fopen($comPort, "w+")) !== false) { 
						fwrite($fp,'FI9'); 
						fclose($fp);
					}
   	}
	exit;
	
	
}
echo "finish sending";
}
?>
<html>
<body>

<center><h1>Arduino from PHP Example 1</h1><b>Version <?php echo $verz; ?></b></center>

<form method="post" action="<?=$_SERVER['PHP_SELF']?>">



Degree: <input type="text" name="degree"><br>
Direction: <select name="direction">
		<option value="west">WEST</option>
		<option value="east">EAST</option></select><br>
<input type="submit">
</form>
<br />

<br />

<br />
<br />
<br />
<br />


</body>
</html>